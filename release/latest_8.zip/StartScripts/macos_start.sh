count=0
while [ $count -lt 3 ]; do
    if ! command -v dotnet &> /dev/null
    then
        echo ".NET runtime ist nicht installiert. Installation wird gestartet..."
        # .NET runtime 8.0 installieren
        brew install --cask dotnet-runtime@8
        count=$((count + 1))
    else
        echo ".NET runtime ist bereits installiert, ueberpruefe Abhaengigkeiten..."
        if ! command -v avrdude &> /dev/null
        then
            echo "Die Anwendung avrdude ist nicht installiert. Installation wird gestartet..."
            brew install avrdude
            count=$((count + 1))
        else
            SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
            cd "$SCRIPT_DIR" || exit
            cd ..
            echo "Starte LMCJC Programmer..."
            echo "Dieses Fenster nicht schliessen! do not close this window!"
            dotnet "LMCJC Programmer.dll" & 
            disown
            count=3
        fi
    fi
done