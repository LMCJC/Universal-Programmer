#!/bin/bash

count=0
while [ $count -lt 3 ]; do
    if ! command -v dotnet &> /dev/null
    then
        echo ".NET runtime ist nicht installiert. Installation wird gestartet..."
        # .NET runtime 8.0 installieren
        sudo apt update
        sudo apt install -y dotnet-runtime-8.0
        count=$((count + 1))
    else
        echo ".NET runtime ist bereits installiert, überprüfe Abhängigkeiten..."
        if ! command -v avrdude &> /dev/null
        then
            echo "Die Anwendung avrdude ist nicht installiert. Installation wird gestartet..."
            sudo apt update
            sudo apt install -y avrdude
            count=$((count + 1))
        else
            SCRIPT_PATH=$(readlink -f "$0")
            SCRIPT_DIR=$(dirname "$SCRIPT_PATH")
            cd "$SCRIPT_DIR" || exit
            cd ..
            echo "Starte LMCJC Programmer..."
            echo "Dieses Fenster nicht schließen! do not close this window!"
            dotnet "LMCJC Programmer.dll" &
            disown
            count=3
        fi
    fi
done


