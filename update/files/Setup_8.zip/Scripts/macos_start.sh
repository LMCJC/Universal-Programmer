count=0
while [ $count -lt 3 ]; do
    if ! command -v dotnet &> /dev/null
    then
        echo ".NET runtime ist nicht installiert. Installation wird gestartet..."
        # .NET runtime 8.0 installieren
        brew install --cask dotnet-runtime@8
        count=$((count + 1))
    else
        echo ".NET runtime ist bereits installiert, �berpr�fe Abh�ngigkeiten..."
        if ! command -v avrdude &> /dev/null
        then
            echo "Die Anwendung avrdude ist nicht installiert. Installation wird gestartet..."
            brew install avrdude
            count=$((count + 1))
        else
            echo "Starte LMCJC UP-Setup... please wait..."
            dotnet "../LMCJC UP-Setup.dll"
            cd "../StartScripts/" || exit
            echo "make script executable..."
            chmod +x macos_start.sh
            exit
        fi
    fi
done