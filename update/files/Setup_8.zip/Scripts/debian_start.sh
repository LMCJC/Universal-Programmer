#!/bin/bash

count=0
while [ $count -lt 3 ]; do
    if ! command -v dotnet &> /dev/null
    then
        echo ".NET runtime ist nicht installiert. Installation wird gestartet..."
        # .NET runtime 8.0 installieren
        sudo apt update
        sudo apt install -y dotnet-runtime-8.0
        count=$((count + 1))
    else
        echo ".NET runtime ist bereits installiert, überprüfe Abhängigkeiten..."
        if ! command -v avrdude &> /dev/null
        then
            echo "Die Anwendung avrdude ist nicht installiert. Installation wird gestartet..."
            sudo apt update
            sudo apt install -y avrdude
            count=$((count + 1))
        else
            echo "Starte LMCJC UP-Setup... please wait..."
            dotnet "../LMCJC UP-Setup.dll"
            exit_code=$?
            if [ $exit_code -eq 0 ]; then
                cd "../StartScripts/" || exit
                echo "make script executable..."
                chmod +x debian_start.sh
                exit
            else
             echo "Setup incomplete or cancel"
             exit
            fi
        fi
    fi
done


